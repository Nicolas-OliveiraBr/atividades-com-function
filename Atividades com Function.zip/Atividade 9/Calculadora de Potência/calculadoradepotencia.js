var x = parseInt(prompt("Digite a base de sua potência:"))
var y = parseInt(prompt("Digite seu expoente:"))

function calculoProduto(a, b) {
    return Math.pow(a, b)
}

const z = calculoProduto(x, y);

alert(`O resultado da potenciação é ${z}.`)