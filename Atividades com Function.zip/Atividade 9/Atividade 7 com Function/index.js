let nascimento = prompt("Digite seu ano de nascimento: ")
let nome = prompt("Digite o seu nome aqui: ")

var x = 2045

function calculoIdade (a, b) {
    return a - b;
}

const y = calculoIdade(x, nascimento)

alert(`Olá, seu nome é ${nome} e você tem ${y} anos.`)
