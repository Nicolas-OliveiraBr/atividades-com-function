let saldoInicial = prompt('Digite seu saldo atual: ')
let produto = prompt('Digite o nome do produto que deseja comprar: ')
let valorProduto = prompt('Digite o valor da compra que quer realizar: ')

function compraRealiz (saldo, produto) {
    return saldo - produto
}

var valorTotal = compraRealiz(saldoInicial, valorProduto)

function compraCancel (produto, saldo) {
    return produto - saldo
}

var valorRestante = compraCancel(valorProduto, saldoInicial)

if (saldoInicial>=valorProduto) {
    alert(`A compra foi realizada com sucesso! Você comprou um(a) ${produto} e seu saldo é de ${valorTotal} reais.`)
}

if (saldoInicial<valorProduto) {
    alert(`Saldo Insuficiente! Você precisa de mais ${valorRestante} reais para completar a compra.`)
}