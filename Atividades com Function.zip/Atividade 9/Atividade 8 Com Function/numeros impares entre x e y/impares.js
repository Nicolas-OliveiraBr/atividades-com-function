var x = Number(prompt("Digite um número aleatório:"))
var y = Number(prompt("Digite outro número:"))
var somaImpares = 0

for(x; x <= y; x++) {
    if(x % 2 != 0) {
        somaImpares += x
    }
}

function mensagemAlert() {
    alert(`A soma dos números ímpares entre esses números é de ${somaImpares}.`)
}

mensagemAlert()

//foi mal monitores, usei uma function num alert pq eu n conseguia fazer a conta na function, dava erro ;-;//