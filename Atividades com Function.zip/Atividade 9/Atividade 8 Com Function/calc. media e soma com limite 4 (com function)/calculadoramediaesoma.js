var limite = 4
var total = 0
var media
var x

for(var valor = 0; valor < 4; valor++) {
   x = Number(prompt(`Digite o ${valor + 1}° valor:`))
   total += x
}

function mediaTotal (a, b) {
   return a / b;
}

var media = mediaTotal(total, limite)

let mensagem = `A soma equivale a ${total} e a média é igual a ${media}.`

alert(mensagem)

