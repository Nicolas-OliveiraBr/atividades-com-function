const y = Number(prompt('Digite um número inteiro aleatório: ' ))
const x = Number(prompt('Digite outro número inteiro aleatório (pode ser o mesmo do anterior): '))
var sinal = prompt('Digite o sinal da operação que quer realizar: ')

function somaTotal (a, b) {
    return a + b
}

const a = somaTotal(y, x)

function subMenos (a, b) {
    return a - b
}

const b = subMenos(y, x)

function multTotal (a, b) {
    return a * b
}

const c = multTotal(y, x)

function divTotal (a, b) {
    return a / b
}

const d = divTotal(y, x)

var add = `O resultado da adição é ${a}.`
var less = `O resultado da subtração é ${b}.`
var times = `O resultado da multiplicação é ${c}.`
var dividedBy = `O resultado da divisão é ${d}.`

if (sinal === '+') {
    alert(add);
} else if (sinal ==='-') {
    alert(less);
} else if (sinal === '*') {
    alert(times);
} else if (sinal === '/') {
    alert(dividedBy);
}