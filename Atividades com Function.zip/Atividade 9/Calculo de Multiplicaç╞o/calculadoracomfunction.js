var x = parseInt(prompt("Digite um fator, em forma de número:"))
var y = parseInt(prompt("Digite outro fator, este também em forma de número:"))

function calculoProduto(a, b) {
    return a * b;
}

const z = calculoProduto(x, y);

alert(`O resultado da multiplicação é ${z}.`)